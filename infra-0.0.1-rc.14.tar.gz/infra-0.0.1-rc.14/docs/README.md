Welcome to *DAOstack Infra* Docs!

*Infra* provide a base layer components for Governance such as Voting Machines and Reputation system.
