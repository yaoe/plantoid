Welcome to contracts documentation!

This directory includes manual markdown documentation for `contracts` directory.
It follows the directory structure of `contracts` (eg. file `foo/bar.md` documents the `bar` contract in `contracts/foo`).

[see the generated documentation](../generated_docs/README.md).
