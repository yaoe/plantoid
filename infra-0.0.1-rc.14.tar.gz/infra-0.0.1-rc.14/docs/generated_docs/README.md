Welcome to the generated documentation!

This directory contains automated documentation generated directly from `.sol` source files.
They include the following info:

- Gas estimates on constructors & functions.
- Technical information about the exposed public interface of each contract.
